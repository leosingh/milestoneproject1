package edu.csulb;

import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

import cecs429.documents.DirectoryCorpus;
import cecs429.documents.Document;
import cecs429.documents.DocumentCorpus;
import cecs429.index.Index;
import cecs429.index.Posting;
import cecs429.index.TermDocumentIndex;
import cecs429.text.BasicTokenProcessor;
import cecs429.text.EnglishTokenStream;

public class BetterTermDocumentIndexer {
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		DocumentCorpus corpus = DirectoryCorpus.loadTextDirectory(
				Paths.get("C:\\Users\\tangudu_amarnath\\Desktop\\Sid Pani\\Final\\SET HW1\\SET HW1\\MobyDick10Chapters")
						.toAbsolutePath(),
				".txt");
		Index index = indexCorpus(corpus);
		// We aren't ready to use a full query parser; for now, we'll only support
		// single-term queries.
		System.out.println("Enter a word: ");
		String query = scanner.nextLine(); // hard-coded search for "whale"
		while (!query.equalsIgnoreCase("quit")) {
			List<Posting> postings = index.getPostings(query);
			if (postings != null && postings.size() > 0) {
				System.out.println("The documents where the term " + query + " is present are:");
				for (Posting p : postings) {
					System.out.println("Document ID " + p.getDocumentId());
				}
			} else {
				System.out.println("Word not found!");
			}
			System.out.println("Enter a word: ");
			query = scanner.nextLine();
		}
		System.out.println("Thank You!");
	}

	private static Index indexCorpus(DocumentCorpus corpus) {
		HashSet<String> vocabulary = new HashSet<>();
		BasicTokenProcessor processor = new BasicTokenProcessor();

		// First, build the vocabulary hash set.

		// TODO:
		// Get all the documents in the corpus by calling GetDocuments().
		// Iterate through the documents, and:
		// Tokenize the document's content by constructing an EnglishTokenStream around
		// the document's content.
		// Iterate through the tokens in the document, processing them using a
		// BasicTokenProcessor,
		// and adding them to the HashSet vocabulary.

		Iterable<Document> documents = corpus.getDocuments();
		documents.forEach(document -> {
			EnglishTokenStream englishTokenStream = new EnglishTokenStream(document.getContent());
			Iterable<String> tokens = englishTokenStream.getTokens();
			tokens.forEach(token -> {
				String processedToken = processor.processToken(token);
				vocabulary.add(processedToken);
			});
		});
		// TODO:
		// Constuct a TermDocumentMatrix once you know the size of the vocabulary.
		// THEN, do the loop again! But instead of inserting into the HashSet, add terms
		// to the index with addPosting.
		TermDocumentIndex termDocumentIndex = new TermDocumentIndex(vocabulary, corpus.getCorpusSize());
		documents.forEach(document -> {
			EnglishTokenStream englishTokenStream = new EnglishTokenStream(document.getContent());
			Iterable<String> tokens = englishTokenStream.getTokens();
			tokens.forEach(token -> {
				String processedToken = processor.processToken(token);
				termDocumentIndex.addTerm(processedToken, document.getId());
			});
		});
		return termDocumentIndex;
	}
}
