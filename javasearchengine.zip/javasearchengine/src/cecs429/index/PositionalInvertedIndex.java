package cecs429.index;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PositionalInvertedIndex implements Index {
	private final Map<String, List<Posting>> positionalInvertedIndexMap;
	private final List<String> mVocabulary;

	public PositionalInvertedIndex(Collection<String> vocabulary) {
		positionalInvertedIndexMap = new HashMap<>();
		mVocabulary = new ArrayList<>();
		mVocabulary.addAll(vocabulary);
		Collections.sort(mVocabulary);
	}

	@Override
	public List<Posting> getPostings(String term) {
		return positionalInvertedIndexMap.get(term);
	}

	@Override
	public List<String> getVocabulary() {
		return mVocabulary;
	}

	public void addTerm(String term, int documentId, int position) {
 		if (positionalInvertedIndexMap.containsKey(term)) {
			List<Posting> currentPostings = positionalInvertedIndexMap.get(term);
			boolean flag = false;
			for (Posting posting : currentPostings) {
				if (posting.getDocumentId() == documentId) {
					posting.getPositions().add(position);
					flag = true;
					break;
				}
			}
			if (!flag) {
				Posting posting = new Posting();
				posting.setmDocumentId(documentId);
				List<Integer> positions = new ArrayList<>();
				positions.add(position);
				posting.setPositions(positions);
				currentPostings.add(posting);
			}
		} else {
			List<Posting> postings = new ArrayList<>();
			Posting posting = new Posting();
			posting.setmDocumentId(documentId);
			List<Integer> positions = new ArrayList<>();
			positions.add(position);
			posting.setPositions(positions);
			postings.add(posting);
			positionalInvertedIndexMap.put(term, postings);
		}
	}
}
