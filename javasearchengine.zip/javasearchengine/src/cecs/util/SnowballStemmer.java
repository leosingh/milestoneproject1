
package cecs.util;

public abstract class SnowballStemmer extends SnowballProgram {
    public abstract boolean stem();
};
