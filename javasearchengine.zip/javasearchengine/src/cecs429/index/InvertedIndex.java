package cecs429.index;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class InvertedIndex implements Index {
	private final Map<String, Set<Integer>> invertedIndexMap;
	private final List<String> mVocabulary;

	public InvertedIndex(Collection<String> vocabulary, int corpuseSize) {
		invertedIndexMap = new HashMap<>();
		mVocabulary = new ArrayList<String>();
		mVocabulary.addAll(vocabulary);
		Collections.sort(mVocabulary);
	}

	@Override
	public List<Posting> getPostings(String term) {
		List<Posting> results = new ArrayList<>();
		try {
			if (invertedIndexMap.keySet().contains(term)) {
				Set<Integer> documentIds = invertedIndexMap.get(term);
				documentIds.forEach(e -> {
					results.add(new Posting(e));
				});
			} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
		return results;
	}

	@Override
	public List<String> getVocabulary() {
		return Collections.unmodifiableList(mVocabulary);
	}

	/**
	 * Associates the given documentId with the given term in the index.
	 */
	public void addTerm(String term, int documentId) {
		if (invertedIndexMap.keySet().contains(term)) {
			Set<Integer> currentSet = invertedIndexMap.get(term);
			currentSet.add(documentId);
		} else {
			Set<Integer> s = new HashSet<>();
			s.add(documentId);
			invertedIndexMap.put(term, s);
		}
	}
}
