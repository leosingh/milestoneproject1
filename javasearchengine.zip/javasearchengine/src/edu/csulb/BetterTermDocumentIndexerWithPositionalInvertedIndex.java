package edu.csulb;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cecs.util.Util;
import cecs429.documents.DirectoryCorpus;
import cecs429.documents.Document;
import cecs429.documents.DocumentCorpus;
import cecs429.index.Index;
import cecs429.index.PositionalInvertedIndex;
import cecs429.index.Posting;
import cecs429.query.BooleanQueryParser;
import cecs429.query.Query;
import cecs429.text.EnglishTokenStream;
import cecs429.text.ExtendedTokenProcessor;
import cecs429.text.TokenProcessor;
import model.MyDocs;
import model.MyDocument;

public class BetterTermDocumentIndexerWithPositionalInvertedIndex {
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		/*
		 * System.out.println("Enter the directory you want to index : "); String
		 * folderName = scanner.nextLine();
		 */
		String folderName = splitJson();
		DocumentCorpus corpus = DirectoryCorpus.loadJsonDirectory(Paths.get(folderName + "\\").toAbsolutePath(),
				".json");
		Index index = indexCorpus(corpus);
		displayMenu();
		String query = scanner.nextLine();
		BooleanQueryParser booleanQueryParser = new BooleanQueryParser();
		while (query != null) {
			if (query.equalsIgnoreCase(":q")) {
				System.out.println("Thank You!");
				System.exit(0);
			} else if (query.startsWith(":stem")) {
				String wordToStem = query.replace(":stem", "").trim();
				String stemmedWord = Util.stemWord(wordToStem);
				System.out.println("The stemmed word is : " + stemmedWord);
			} else if (query.startsWith(":index")) {
				String directoryToIndex = query.replace(":index", "").trim();
				corpus = DirectoryCorpus.loadJsonDirectory(Paths.get(directoryToIndex + "\\").toAbsolutePath(),
						".json");
				index = indexCorpus(corpus);
				System.out.println(directoryToIndex + " indexed.");
			} else if (query.equalsIgnoreCase(":vocab")) {
				List<String> sublist = index.getVocabulary().subList(0, 1000);
				sublist.forEach(word -> {
					System.out.print(word + ",");
				});
				System.out.println();
			} else {
				Query obj = booleanQueryParser.parseQuery(query);
				List<Posting> postings = obj.getPostings(index);
//				List<Posting> postings = index.getPostings(query.toLowerCase());
				if (postings != null && !postings.isEmpty()) {
					System.out.println("The documents where the term \'" + query + "\' is present are:");
					for (Posting p : postings) {
						System.out.println("Document ID " + p.getDocumentId());
						System.out.println("Positions : ");
						for (int pos : p.getPositions()) {
							System.out.println(pos);
						}
						System.out.println();
					}
					System.out.println("Enter a Document Id for which you want to see the actual text:");
					int docId = scanner.nextInt();
					try {
						String content = new String(
								Files.readAllBytes(Paths.get(folderName + "doc" + docId + ".json")));
						Gson gson = new Gson();
						MyDocument doc = gson.fromJson(content, MyDocument.class);
						System.out.println(doc.getBody());
					} catch (IOException e) {
						e.printStackTrace();
					}

				} else {
					System.out.println("Word not found!");
				}
				scanner.nextLine();
			}
			displayMenu();
			query = scanner.nextLine();
		}
	}

	private static Index indexCorpus(DocumentCorpus corpus) {
		long start = System.currentTimeMillis();
		HashSet<String> vocabulary = new HashSet<>();
		TokenProcessor processor = new ExtendedTokenProcessor();
		Iterable<Document> documents = corpus.getDocuments();
		// Create the vocabulary
		documents.forEach(document -> {
			EnglishTokenStream englishTokenStream = new EnglishTokenStream(document.getContent());
			Iterable<String> tokens = englishTokenStream.getTokens();
			tokens.forEach(token -> {
				List<String> processedTokens = processor.processToken(token);
				vocabulary.addAll(processedTokens);
			});
		});

		// Create index for all the documents
		PositionalInvertedIndex index = new PositionalInvertedIndex(vocabulary);
		documents.forEach(document -> {
			EnglishTokenStream englishTokenStream = new EnglishTokenStream(document.getContent());
			Iterable<String> tokens = englishTokenStream.getTokens();
			Iterator<String> iter = tokens.iterator();
			int position = 1;
			while (iter.hasNext()) {
				List<String> processedTokens = processor.processToken(iter.next());
				for (String processedToken : processedTokens) {
					index.addTerm(processedToken, document.getId(), position);
				}
				position++;
			}
			try {
				englishTokenStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		long end = System.currentTimeMillis();
		System.out.println((end - start) / 1000 + " seconds to index.");
		return index;
	}

	private static String splitJson() {
		String folderName = "";
		Gson gson = new Gson();
		MyDocs file = null;
		try {
//			System.out.println("Reading JSON from a file");
//			System.out.println("----------------------------");
			BufferedReader bufferedReader = new BufferedReader(new FileReader(
					"C:\\Users\\tangudu_amarnath\\Desktop\\Sid Pani\\all-nps-sites\\all-nps-sites.json"));
			file = gson.fromJson(bufferedReader, MyDocs.class);
//			System.out.println("JSON File read.");
//			System.out.println("Creating Folder.");
			folderName = "C:\\Users\\tangudu_amarnath\\Desktop\\Sid Pani\\" + new Date().toString().replaceAll(":", "")
					+ "\\";
			Path path = Paths.get(folderName);
			Files.createDirectories(path);
//			System.out.println("Folder is created! " + folderName);
			List<MyDocument> documents = file.getDocuments();
			System.out.println("Number of documents: " + documents.size());
//			System.out.println("Creating Documents.");
			for (int i = 0; i < documents.size(); i++) {
				// To Test
				if (i == 10)
					break;
				Gson gson2 = new GsonBuilder().setPrettyPrinting().create(); // pretty print
				String json = gson2.toJson(documents.get(i));
				FileWriter writer = null;
				try {
					writer = new FileWriter(folderName + "doc" + (i) + ".json");
					writer.write(json);
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					writer.close();
				}

			}
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
//		System.out.println("Documents created.");
		return folderName;
	}

	public static void displayMenu() {
		System.out.println("=========================MENU=========================");
		System.out.println(":q -> Quit the program.");
		System.out.println(":stem <word> -> To find the token of the word.");
		System.out.println(":index <directory_name> -> To index the given directory.");
		System.out.println(":vocab -> To get the first 1000 words in the vocabulary.");
		System.out.println("Any other word or query -> To search in the index.");
		System.out.println("======================================================");
	}
}
